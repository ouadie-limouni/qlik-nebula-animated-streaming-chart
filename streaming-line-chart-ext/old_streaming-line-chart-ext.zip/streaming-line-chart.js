define(['./dist/streaming-line-chart'], (supernova) => supernova);
